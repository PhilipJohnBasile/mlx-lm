import argparse,cProfile,json,pstats,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/"experiments/m5_inference"))
import mlx.core as mx
from mlx_lm import load
from benchmark_requests import request,texts,memory,sha256
p=argparse.ArgumentParser();p.add_argument("--model",required=True);p.add_argument("--output",type=Path,required=True);a=p.parse_args()
a.output.mkdir(exist_ok=False)
mx.set_memory_limit(90_000_000_000);mx.set_cache_limit(2_000_000_000)
model,tokenizer=load(a.model)
result={"scope":"Instrumented diagnostic; cProfile overhead prevents using these as performance acceptance samples.","model":a.model,"source_sha256":sha256(__file__),"memory_before":memory(),"profiles":[]}
for prompt_len in (32,2048):
 prompts=texts(tokenizer,prompt_len,1)
 request(model,tokenizer,prompts,"reference",8,512)
 prof=cProfile.Profile();prof.enable()
 r,_=request(model,tokenizer,prompts,"reference",64,512)
 prof.disable();prof.dump_stats(str(a.output/f"s{prompt_len}.pstats"))
 stats=pstats.Stats(prof)
 rows=[dict(file=k[0],line=k[1],function=k[2],primitive_calls=v[0],calls=v[1],own_s=v[2],cumulative_s=v[3]) for k,v in stats.stats.items()]
 result["profiles"].append({"prompt_length":prompt_len,"request":r,"by_own":sorted(rows,key=lambda r:r["own_s"],reverse=True)[:40],"by_cumulative":sorted(rows,key=lambda r:r["cumulative_s"],reverse=True)[:40]})
result["memory_after"]=memory();(a.output/"report.json").write_text(json.dumps(result,indent=2))
for case in result["profiles"]:
 print("S",case["prompt_length"],"elapsed_ms",case["request"]["elapsed_ms"])
 for row in case["by_own"][:12]: print(row)
